import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-task-management',
  templateUrl: './task-management.component.html',
  styleUrls: ['./task-management.component.css']
})
export class TaskManagementComponent implements OnInit {
  totalActivity = 95;
  activities = [
  {'name': 'New Order',
    'count': 29,
    'percent': '15% from this yesterday' },
    {'name': 'To Be Shipped',
    'count': 35,
    'percent': '15% from this yesterday' },
    {'name': 'To Be Invoiced',
    'count': 17,
    'percent': '15% from this yesterday' },
    {'name': 'To Be Delivered',
    'count': 24,
    'percent': '15% from this yesterday' }
  ];

  tasks = [{name: 'High', count:30},
  {name: 'Medium', count:20},
  {name: 'Low', count:15}];


  Variants = [
    {fName:'Arbutus', lName:'Marina', age:25},
    {fName:'Sempervirsens', lName:'Buxus', age:25},
    {fName:'Camellia', lName:'Jab Purity', age:25},
    {fName:'Betula', lName:'Utilis', age:25}
  ];

  products = [
    {name: 'Refrigerator', src:'../../assets/Asset 2.png'},
    {name: 'Washing Machine', src:'../../assets/Asset 4.png'},
    {name: 'TV', src:'../../assets/Asset 5.png'},
    {name: 'Niddi Kumari', src:'../../assets/Asset 3.png'},


  ]

  constructor() { }

  ngOnInit(): void {
  }

}
