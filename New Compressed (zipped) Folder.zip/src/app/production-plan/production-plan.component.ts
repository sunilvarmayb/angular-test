import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-production-plan',
  templateUrl: './production-plan.component.html',
  styleUrls: ['./production-plan.component.css']
})
export class ProductionPlanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
