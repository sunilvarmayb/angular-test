import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { TaskManagementComponent } from './task-management/task-management.component';
import { SalesComponent } from './sales/sales.component';
import { PurchasesComponent } from './purchases/purchases.component';
import { ProductionPlanComponent } from './production-plan/production-plan.component';
import { ReportsComponent } from './reports/reports.component';
import { StocksComponent } from './stocks/stocks.component';

const routes: Routes = [
  {path:'dashboard', component: DashboardComponent },
  {path:'task', component: TaskManagementComponent },
  {path:'sale', component: SalesComponent },
  {path: 'purchase', component: PurchasesComponent},
  {path: 'production', component: ProductionPlanComponent},
  {path: 'reports', component: ReportsComponent},
  {path: 'stocks', component: StocksComponent},
  {path:'', component: TaskManagementComponent, pathMatch:'full' },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
